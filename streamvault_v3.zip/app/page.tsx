
import Link from 'next/link';
export default function Home(){
return <main style={{minHeight:'100vh',background:'linear-gradient(180deg,#111,#000)',padding:'80px 40px'}}>
<h1 style={{fontSize:72,margin:0}}>STREAMVAULT</h1>
<p style={{color:'#aaa',maxWidth:620,fontSize:20}}>Netflix-style premium streaming experience with real auth, watchlists, and admin CMS.</p>
<div style={{display:'flex',gap:12,marginTop:20}}>
<a href='/browse' style={{padding:'12px 18px',background:'#e50914',color:'#fff',textDecoration:'none',borderRadius:8}}>Browse</a>
<a href='/login' style={{padding:'12px 18px',border:'1px solid #555',color:'#fff',textDecoration:'none',borderRadius:8}}>Login</a>
</div>
</main>}
