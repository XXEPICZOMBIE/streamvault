
export const metadata={title:'StreamVault V3',description:'Premium streaming platform'};
export default function RootLayout({children}:{children:React.ReactNode}){
return <html><body style={{margin:0,fontFamily:'Inter,Arial',background:'#000',color:'#fff'}}>{children}</body></html>}
