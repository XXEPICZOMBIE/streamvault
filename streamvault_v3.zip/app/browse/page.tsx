
'use client';
import {motion} from 'framer-motion';
const items=[
{t:'Inception',img:'https://image.tmdb.org/t/p/w500/9gk7adHYeDvHkCSEqAvQNLV5Uge.jpg'},
{t:'Interstellar',img:'https://image.tmdb.org/t/p/w500/gEU2QniE6E77NI6lCU6MxlNBvIx.jpg'},
{t:'The Dark Knight',img:'https://image.tmdb.org/t/p/w500/qJ2tW6WMUDux911r6m7haRef0WH.jpg'},
{t:'Avatar',img:'https://image.tmdb.org/t/p/w500/kyeqWdyUXW608qlYkRqosgbbJyK.jpg'}
];
export default function Browse(){
return <main style={{padding:30}}>
<h1>Trending Now</h1>
<div style={{display:'grid',gridTemplateColumns:'repeat(auto-fit,minmax(220px,1fr))',gap:18}}>
{items.map((x,i)=><motion.div whileHover={{scale:1.08,y:-8}} key={i} style={{background:'#111',borderRadius:18,overflow:'hidden'}}>
<img src={x.img} style={{width:'100%',height:320,objectFit:'cover'}}/>
<div style={{padding:14}}>
<div>{x.t}</div>
<div style={{display:'flex',gap:8,marginTop:10}}>
<button style={{padding:'10px 12px',background:'#fff'}}>Play</button>
<button style={{padding:'10px 12px'}}>+ Watchlist</button>
</div>
</div>
</motion.div>)}
</div></main>}
