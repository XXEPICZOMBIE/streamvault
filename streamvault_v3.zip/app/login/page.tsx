
'use client';
import {useState} from 'react';
export default function Login(){
const [email,setEmail]=useState('');
const [password,setPassword]=useState('');
return <div style={{padding:40,maxWidth:420}}>
<h1>Login</h1>
<input style={{display:'block',width:'100%',marginBottom:10,padding:10}} placeholder='Email' value={email} onChange={e=>setEmail(e.target.value)} />
<input type='password' style={{display:'block',width:'100%',marginBottom:10,padding:10}} placeholder='Password' value={password} onChange={e=>setPassword(e.target.value)} />
<button style={{padding:12,width:'100%',background:'#e50914',color:'#fff'}}>Login with Supabase</button>
</div>}
