
export default function Admin(){
return <main style={{padding:40}}>
<h1>Admin CMS</h1>
<p>Upload posters, manage titles, edit metadata, moderate users.</p>
<button>Create Movie</button> <button>Upload Poster</button>
</main>}
