
export default function Page(){return <div style={{padding:40}}><h1>Signup</h1><p>Create account with Supabase Auth.</p></div>}
